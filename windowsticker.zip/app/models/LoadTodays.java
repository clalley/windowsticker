package models;



public class LoadTodays  {

}
