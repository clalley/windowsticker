package models;

//import play.db.ebean.Model;

//public class CreateNew extends Model {
public class CreateNew {

}
