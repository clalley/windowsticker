package models;

//import play.db.ebean.Model;


//public class Index extends Model {
    public class Index {
}
